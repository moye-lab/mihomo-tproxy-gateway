fake js
